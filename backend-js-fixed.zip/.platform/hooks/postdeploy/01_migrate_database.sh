#!/bin/bash

# Run database migrations after deployment
set -e

echo "Running database migrations..."

# Only run migrations if DATABASE_URL is set
if [ -n "$DATABASE_URL" ]; then
    echo "DATABASE_URL found, running Prisma migrations..."
    npx prisma migrate deploy
    echo "Database migrations completed successfully!"
else
    echo "DATABASE_URL not set, skipping database migrations"
fi

echo "Post-deployment tasks completed!"