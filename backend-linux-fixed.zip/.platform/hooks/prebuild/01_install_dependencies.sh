#!/bin/bash

# Install dependencies and generate Prisma client
set -e

echo "Installing Node.js dependencies..."
npm ci --only=production

echo "Generating Prisma client..."
npx prisma generate

echo "Building TypeScript application..."
npm run build

echo "Prebuild completed successfully!"